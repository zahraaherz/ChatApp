//
//  MassageCell.swift
//  ChatApp
//
//  Created by Zahraa Herz on 06/02/2023.
//

import UIKit

class MassageCell: UITableViewCell {

    @IBOutlet weak var massageBubble: UIView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var rightImageView: UIImageView!
    @IBOutlet weak var leftImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        massageBubble.layer.cornerRadius = massageBubble.frame.size.height / 5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
