//
//  Massage.swift
//  ChatApp
//
//  Created by Zahraa Herz on 06/02/2023.
//

import Foundation

struct Massage {
    let sender: String
    let body: String
    
}
