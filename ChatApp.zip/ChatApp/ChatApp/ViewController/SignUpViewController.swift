//
//  SignUpViewController.swift
//  ChatApp
//
//  Created by Zahraa Herz on 01/02/2023.
//

import Foundation
import UIKit
import Firebase

class SignUpViewController: UIViewController {

    @IBOutlet var emailText: UITextField!
    
    @IBOutlet var passwordText: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func emailTextField(_ sender: UITextField) {
        
    }
    
    @IBAction func passwordTextField(_ sender: UITextField) {
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
        
        if let email = emailText.text , let password = passwordText.text {
            Auth.auth().createUser(withEmail: email , password: password) { authResult, error in
                if let e = error{
                    print(e.localizedDescription)
                }else{
                    self.performSegue(withIdentifier: "siginUpToChatNavigation", sender: self)
                }
            }
        }
    }
    
}
