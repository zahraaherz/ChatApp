//
//  ChitChatViewController.swift
//  ChatApp
//
//  Created by Zahraa Herz on 01/02/2023.
//

import Foundation
import UIKit
import Firebase

class ChitChatViewController: UIViewController {
    
    let firebaseAuth = Auth.auth()
    let db = Firestore.firestore()
    var massages : [Massage] = []
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var massageTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        navigationItem.hidesBackButton = true
        
        tableView.register(UINib(nibName: "MassageCell", bundle: nil), forCellReuseIdentifier: "tableCell")
        loadMassages()
    }
    
    func loadMassages(){
        
        
        db.collection("Massage")
            .order(by: "Date")
            .addSnapshotListener{ (querySnapshot, err) in
            
                self.massages = []

            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                   
                    let data = document.data()
                    if let sender = data["sender"] as? String , let body = data["body"] as? String{
                        self.massages.append(Massage(sender: sender, body: body))
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                            let index = IndexPath(row: self.massages.count - 1 , section: 0)
                            self.tableView.scrollToRow(at: index, at: .top, animated: true)
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func sendButton(_ sender: UIButton) {
        
        if let massageBody = massageTextField.text , let sender = firebaseAuth.currentUser?.email{
            db.collection("Massage").addDocument(data: [
                "body": massageBody,
                "sender": sender,
                "Date": Date().timeIntervalSince1970
            ]) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Document added with ID:")
                    DispatchQueue.main.async {
                        self.massageTextField.text = ""
                    }
                }
            }
        }
    }
    
    @IBAction func logOutButton(_ sender: UIBarButtonItem) {
        
        do {
          try firebaseAuth.signOut()
            navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError {
          print("Error signing out: %@", signOutError)
        }
          
    }
    
    
    
}

extension ChitChatViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return massages.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let massage = massages[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! MassageCell
        cell.label?.text = massage.body
        
        if massage.sender == firebaseAuth.currentUser?.email {
            cell.leftImageView.isHidden = true
            cell.rightImageView.isHidden = false
            cell.massageBubble.backgroundColor = UIColor(hue: 43/360, saturation: 6/100, brightness: 92/100, alpha: 1.0) /* #ece8dd */

        }else {
            cell.leftImageView.isHidden = false
            cell.rightImageView.isHidden = true
        }
        return cell
    }

    
}
