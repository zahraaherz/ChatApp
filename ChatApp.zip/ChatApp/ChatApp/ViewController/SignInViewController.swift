//
//  SignInViewController.swift
//  ChatApp
//
//  Created by Zahraa Herz on 01/02/2023.
//

import Foundation
import UIKit
import Firebase

class SignInViewController: UIViewController {

    @IBOutlet var emailText: UITextField!
    @IBOutlet var passwordText: UITextField!
    
    override func viewDidLoad() {
             super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func signInButton(_ sender: Any) {

        if let email = emailText.text , let password = passwordText.text {
            Auth.auth().signIn(withEmail: email, password: password) { [weak self] authResult, error in
                if let e = error{
                    print(e.localizedDescription)
                }else{
                    self?.performSegue(withIdentifier: "siginInToChatNavigation", sender: self)
                }
                
              
            }
        }
       
    }
}
