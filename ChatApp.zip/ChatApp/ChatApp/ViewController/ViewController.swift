//
//  ViewController.swift
//  ChatApp
//
//  Created by Zahraa Herz on 01/02/2023.
//

import UIKit
import CLTypingLabel

class ViewController: UIViewController {

    @IBOutlet var chitChatLabel: CLTypingLabel!
    @IBOutlet var signUp: UIButton!
    @IBOutlet var signIn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        chitChatLabel.text = "ChitChat"
    }


}

